
CREATE TABLE game (
    game_id SERIAL PRIMARY KEY,
    season_id INTEGER NOT NULL,
    game_date DATE NOT NULL
);

CREATE TABLE team (
    team_id SERIAL PRIMARY KEY,
    abbreviation VARCHAR(10),
    nickname VARCHAR(50),
    city VARCHAR(50),
    state VARCHAR(50),
    year_founded INTEGER,
    full_name VARCHAR(50)
);

CREATE TABLE player (
    player_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    birthdate DATE,
    school VARCHAR(100),
    country VARCHAR(50),
    nba_flag BOOLEAN,
    draft_year INTEGER,
    draft_round INTEGER,
    draft_number INTEGER
);

CREATE TABLE officials (
    official_id SERIAL PRIMARY KEY,
    game_id INTEGER REFERENCES game(game_id) ON DELETE CASCADE,
    first_name VARCHAR(50),
    last_name VARCHAR(50)
);


CREATE TABLE game_summary (
    game_id INTEGER PRIMARY KEY REFERENCES game(game_id) ON DELETE CASCADE,
    game_status_id INTEGER NOT NULL,
    game_status_text VARCHAR(50),
    home_team_id INTEGER REFERENCES team(team_id) ON DELETE CASCADE,
    visitor_team_id INTEGER REFERENCES team(team_id) ON DELETE CASCADE,
    season INTEGER NOT NULL
);


CREATE TABLE game_line_score (
    game_id INTEGER REFERENCES game(game_id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES team(team_id) ON DELETE CASCADE,
    quarter INTEGER,
    points INTEGER,
    PRIMARY KEY (game_id, team_id, quarter)
);


CREATE TABLE player_stats (
    game_id INTEGER REFERENCES game(game_id) ON DELETE CASCADE,
    player_id INTEGER REFERENCES player(player_id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES team(team_id) ON DELETE CASCADE,
    points INTEGER,
    assists INTEGER,
    rebounds INTEGER,
    steals INTEGER,
    blocks INTEGER,
    turnovers INTEGER,
    PRIMARY KEY (game_id, player_id, team_id)
);


CREATE TABLE team_stats (
    game_id INTEGER REFERENCES game(game_id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES team(team_id) ON DELETE CASCADE,
    points INTEGER,
    rebounds INTEGER,
    assists INTEGER,
    turnovers INTEGER,
    fouls INTEGER,
    PRIMARY KEY (game_id, team_id)
);


CREATE TABLE inactive_players (
    game_id INTEGER REFERENCES game(game_id) ON DELETE CASCADE,
    player_id INTEGER REFERENCES player(player_id) ON DELETE CASCADE,
    team_id INTEGER REFERENCES team(team_id) ON DELETE CASCADE,
    PRIMARY KEY (game_id, player_id)
);


CREATE TABLE draft_history (
    draft_history_id SERIAL PRIMARY KEY,
    person_id INTEGER REFERENCES player(player_id) ON DELETE CASCADE,
    season INTEGER NOT NULL,
    round_number INTEGER,
    round_pick INTEGER,
    overall_pick INTEGER,
    team_id INTEGER REFERENCES team(team_id) ON DELETE CASCADE
);
